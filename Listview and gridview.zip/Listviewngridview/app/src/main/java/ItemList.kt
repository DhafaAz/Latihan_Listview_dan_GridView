package id.sttbandung.gridviewctx

data class ItemList(
    var judul: String,
    var subJudul: String,
    var imageURL: String
)
